# [Dockerized] (http://www.docker.com) [gnatsd](https://registry.hub.docker.com/u/apcera/gnatsd/)

A docker image for gnatsd. This is created as a single static executable, so there are multiple passes through Docker to first build the static executable and then to package it under an empty (scratch) base image.



